package ch.heigvd.iict.and.rest.models

enum class PhoneType {
    HOME, OFFICE, MOBILE, FAX
}